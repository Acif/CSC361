* How to run and compile
Usage: python3 WebTester.py <website>

There is a strict HTTP setting on line 14 which allows the program to only work on HTTP and not HTTPS. Since the assignment outline says that it focuses on HTTP and not HTTPS I figured that I would include this. With this mode on, the program will not allow redirects to HTTPS.
